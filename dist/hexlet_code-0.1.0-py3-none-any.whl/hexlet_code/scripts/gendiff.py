#!/usr/bin/env python


def main():
    print("Welcome!!!!")


if __name__ == '__main__':
    main()
